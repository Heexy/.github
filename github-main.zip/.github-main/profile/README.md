<p align="center">
  <img width="612" height="240" src="https://i.imgur.com/GHFShCv.png">
</p>

## 👋 About us
QBCore is an organization that provides open source code for the FiveM community. We pride ourselves on always advancing the way we develop and hope to pass that knowledge on to our community!

## 📚 Documentation
https://docs.qbcore.org/

## 👉 Join the community
<p>
  <a href="https://discord.gg/qbcore"><img src="https://discordapp.com/api/guilds/831626422232678481/widget.png?style=banner2" alt="Discord server"></a>
</p>

## 👨‍💻 Meet the team
<p align="center">
 <a href=https://ko-fi.com/kakarot><img width="420" src=https://github-readme-stats.vercel.app/api?username=GhzGarage&count_private=true&show_icons=true&title_color=dc143c&text_color=ffffff&icon_color=dc143c&hide_border=true&bg_color=282a36&layout=compact&hide_title=false&hide_rank=false><a>
<a href=https://github.com/IdrisDose><img width="420" src=https://github-readme-stats.vercel.app/api?username=IdrisDose&count_private=true&show_icons=true&title_color=dc143c&text_color=ffffff&icon_color=dc143c&hide_border=true&bg_color=282a36&layout=compact&hide_title=false&hide_rank=false><a>
 <a href=https://github.com/BerkieBb><img width="420" src=https://github-readme-stats.vercel.app/api?username=BerkieBb&count_private=true&show_icons=true&title_color=dc143c&text_color=ffffff&icon_color=dc143c&hide_border=true&bg_color=282a36&layout=compact&hide_title=false&hide_rank=false><a>
 <a href=https://github.com/TheiLLeniumStudios><img width="420" src=https://github-readme-stats.vercel.app/api?username=TheiLLeniumStudios&count_private=true&show_icons=true&title_color=dc143c&text_color=ffffff&icon_color=dc143c&hide_border=true&bg_color=282a36&layout=compact&hide_title=false&hide_rank=false><a>
 <a href=https://github.com/deandum><img width="420" src=https://github-readme-stats.vercel.app/api?username=deandum&count_private=true&show_icons=true&title_color=dc143c&text_color=ffffff&icon_color=dc143c&hide_border=true&bg_color=282a36&layout=compact&hide_title=false&hide_rank=false><a>
 <a href=https://github.com/FildonPrime><img width="420" src=https://github-readme-stats.vercel.app/api?username=FildonPrime&count_private=true&show_icons=true&title_color=dc143c&text_color=ffffff&icon_color=dc143c&hide_border=true&bg_color=282a36&layout=compact&hide_title=false&hide_rank=false><a>
 <a href=https://github.com/FjamZoo><img width="420" src=https://github-readme-stats.vercel.app/api?username=FjamZoo&count_private=true&show_icons=true&title_color=dc143c&text_color=ffffff&icon_color=dc143c&hide_border=true&bg_color=282a36&layout=compact&hide_title=false&hide_rank=false><a>
 <a href=https://github.com/ItsANoBrainer><img width="420" src=https://github-readme-stats.vercel.app/api?username=ItsANoBrainer&count_private=true&show_icons=true&title_color=dc143c&text_color=ffffff&icon_color=dc143c&hide_border=true&bg_color=282a36&layout=compact&hide_title=false&hide_rank=false><a>
<a href=https://github.com/MatthewRorke><img width="420" src=https://github-readme-stats.vercel.app/api?username=MatthewRorke&count_private=true&show_icons=true&title_color=dc143c&text_color=ffffff&icon_color=dc143c&hide_border=true&bg_color=282a36&layout=compact&hide_title=false&hide_rank=false><a>
<a href=https://github.com/nullvariable><img width="420" src=https://github-readme-stats.vercel.app/api?username=nullvariable&count_private=true&show_icons=true&title_color=dc143c&text_color=ffffff&icon_color=dc143c&hide_border=true&bg_color=282a36&layout=compact&hide_title=false&hide_rank=false><a>
 <a href=https://github.com/Sna-aaa><img width="420" src=https://github-readme-stats.vercel.app/api?username=sna-aaa&count_private=true&show_icons=true&title_color=dc143c&text_color=ffffff&icon_color=dc143c&hide_border=true&bg_color=282a36&layout=compact&hide_title=false&hide_rank=false><a>
<a href=https://github.com/uShifty><img width="420" src=https://github-readme-stats.vercel.app/api?username=uShifty&count_private=true&show_icons=true&title_color=dc143c&text_color=ffffff&icon_color=dc143c&hide_border=true&bg_color=282a36&layout=compact&hide_title=false&hide_rank=false><a>
  </p>
